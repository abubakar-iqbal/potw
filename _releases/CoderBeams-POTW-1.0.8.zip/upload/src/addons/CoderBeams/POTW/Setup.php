<?php

namespace CoderBeams\POTW;

use XF\AddOn\AbstractSetup;
use XF\AddOn\StepRunnerInstallTrait;
use XF\AddOn\StepRunnerUninstallTrait;
use XF\AddOn\StepRunnerUpgradeTrait;
use XF\Db\Schema\Alter;
use XF\Db\Schema\Create;

class Setup extends AbstractSetup
{
    use StepRunnerInstallTrait;
    use StepRunnerUpgradeTrait;
    use StepRunnerUninstallTrait;

    /**
     * Upgrade Step 1: This will run if upgrading the add-on, making sure that necessary changes to the table are applied.
     */
    public function upgrade16Step1(array $stepParams = [])
    {
        $schemaManager = $this->schemaManager();

        // Check if the table exists before trying to create it
        if (!$schemaManager->tableExists('xf_potw_watch')) {
            // If the table doesn't exist, create it
            $this->installStep1();  // Call the installStep1 to create the table
        }

    }

    /**
     * Install Step 1: Create the xf_potw_watch table for tracking watched users
     */
    public function installStep1(array $stepParams = [])
    {
        $this->schemaManager()->createTable('xf_potw_watch', function (Create $table) {
            $table->addColumn('user_id', 'int')->comment('User who is watching the posts');
            $table->addColumn('time_lapse', 'enum', ['values' => ['day', 'week']])->comment(
                'Time period for watching (Post of the Day or Week)'
            );
            $table->addColumn('watch_date', 'int')->setDefault(0)->comment('Timestamp when the user started watching');
            $table->addPrimaryKey(['user_id', 'time_lapse']);
            $table->addKey('time_lapse');  // Add index for time_lapse
        });
    }

    /**
     * Install Step 2: Create the xf_cb_potw_winner table for tracking POTW wins
     */
    public function installStep2(array $stepParams = [])
    {
        $sm = $this->schemaManager();

        if ($sm->tableExists('xf_cb_potw_winner')) {
            return;
        }

        $sm->createTable('xf_cb_potw_winner', function (Create $table) {
            $table->addColumn('potw_winner_id', 'int')->autoIncrement();
            $table->addColumn('user_id', 'int')->comment('User who won the POTW');
            $table->addColumn('post_id', 'int')->comment('The winning post');
            $table->addColumn('time_lapse', 'enum', ['values' => ['day', 'week']])->setDefault('week');
            $table->addColumn('period', 'varchar', 10)->comment('ISO year-week identifier, e.g. 2026-26');
            $table->addColumn('won_date', 'int')->setDefault(0);
            $table->addUniqueKey(['time_lapse', 'period'], 'time_lapse_period');
            $table->addKey('user_id');
        });
    }

    /**
     * Install Step 3: Add the cached POTW win counter to the user table
     */
    public function installStep3(array $stepParams = [])
    {
        $sm = $this->schemaManager();

        if ($sm->columnExists('xf_user', 'cb_potw_count')) {
            return;
        }

        $sm->alterTable('xf_user', function (Alter $table) {
            $table->addColumn('cb_potw_count', 'int')->setDefault(0)->comment('Number of POTW wins');
        });
    }

    /**
     * Upgrade to 1.0.8: add winner tracking
     */
    public function upgrade18Step1(array $stepParams = [])
    {
        $this->installStep2();
    }

    public function upgrade18Step2(array $stepParams = [])
    {
        $this->installStep3();
    }

    /**
     * Uninstall Step 1: Drop the table when uninstalling the add-on
     */
    public function uninstallStep1(array $stepParams = [])
    {
        $this->schemaManager()->dropTable('xf_potw_watch');
    }

    public function uninstallStep2(array $stepParams = [])
    {
        $this->schemaManager()->dropTable('xf_cb_potw_winner');
    }

    public function uninstallStep3(array $stepParams = [])
    {
        $sm = $this->schemaManager();

        if ($sm->columnExists('xf_user', 'cb_potw_count')) {
            $sm->alterTable('xf_user', function (Alter $table) {
                $table->dropColumns('cb_potw_count');
            });
        }
    }
}
