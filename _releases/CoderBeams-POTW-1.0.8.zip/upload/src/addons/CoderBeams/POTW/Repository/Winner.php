<?php

namespace CoderBeams\POTW\Repository;

use XF\Mvc\Entity\Repository;

class Winner extends Repository
{
    /**
     * Determine the top post of the week that just ended and record it as a win.
     * Safe to call repeatedly: only one winner is recorded per ISO week.
     *
     * @return \CoderBeams\POTW\Entity\Winner|null
     */
    public function recordWeeklyWinner()
    {
        $weekService = new \CoderBeams\POTW\Service\Week($this->app());
        $range = $weekService->getWeekRange(-1, \XF::visitor());

        // Stable identifier for the completed week (range start is the Sunday
        // before the ISO week's Monday, so shift a day forward)
        $period = date('o-W', $range['start'] + 86400);

        $existing = $this->finder('CoderBeams\POTW:Winner')
            ->where('time_lapse', 'week')
            ->where('period', $period)
            ->fetchOne();
        if ($existing) {
            return $existing;
        }

        $post = $this->getTopPostForRange($range['start'], $range['end']);
        if (!$post || !$post->user_id) {
            return null; // no qualifying post, or a guest post
        }

        $winner = $this->em->create('CoderBeams\POTW:Winner');
        $winner->user_id = $post->user_id;
        $winner->post_id = $post->post_id;
        $winner->time_lapse = 'week';
        $winner->period = $period;
        $winner->won_date = \XF::$time;
        $winner->save();

        $this->rebuildUserPotwCount($post->user_id);

        return $winner;
    }

    /**
     * @return \XF\Entity\Post|null
     */
    protected function getTopPostForRange(int $start, int $end)
    {
        $options = $this->options();

        $postFinder = $this->finder('XF:Post');
        $postFinder
            ->where('Thread.discussion_state', 'visible')
            ->where('message_state', 'visible')
            ->where('reaction_score', '>=', $options->cb_potw_reaction_limit ?? 1)
            ->where('post_date', '>=', $start)
            ->where('post_date', '<=', $end)
            ->order('reaction_score', 'DESC')
            ->order('post_date', 'ASC'); // ties go to the earlier post

        $nodeIds = $options->cb_potw_applicable_forum ?? [];
        if (!empty($nodeIds) && !in_array(0, $nodeIds)) {
            $postFinder->where('Thread.node_id', $nodeIds);
        }

        return $postFinder->fetchOne();
    }

    /**
     * Recalculate the cached win counter on the user record
     */
    public function rebuildUserPotwCount(int $userId): int
    {
        $count = $this->finder('CoderBeams\POTW:Winner')
            ->where('user_id', $userId)
            ->total();

        $this->db()->update('xf_user', ['cb_potw_count' => $count], 'user_id = ?', $userId);

        return $count;
    }
}
