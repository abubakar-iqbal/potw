<?php

namespace CoderBeams\POTW\Cron;

class PotwAlert
{
    public static function runJob()
    {
        // Only alert if a qualifying post exists in the last 24 hours
        $end = \XF::$time;
        $start = $end - 86400;

        if (!self::hasQualifyingPosts($start, $end)) {
            return false;
        }

        return self::alertWatchers('day', 'potw_day', \XF::phrase('cb_potw_day_alert'));
    }

    public static function runJobWeekly()
    {
        // Record the winner of the week that just ended (no-op if already recorded)
        \XF::app()->repository('CoderBeams\POTW:Winner')->recordWeeklyWinner();

        // Only alert if a qualifying post exists in the week that just ended
        $weekService = new \CoderBeams\POTW\Service\Week(\XF::app());
        $range = $weekService->getWeekRange(-1, \XF::visitor());

        if (!self::hasQualifyingPosts($range['start'], $range['end'])) {
            return false;
        }

        return self::alertWatchers('week', 'potw_week', \XF::phrase('cb_potw_week_alert'));
    }

    /**
     * Mirrors the visibility/reaction/forum criteria used by the POTW page,
     * so watchers are only alerted when the page will actually show something.
     */
    protected static function hasQualifyingPosts(int $start, int $end): bool
    {
        $options = \XF::options();

        $postFinder = \XF::app()->finder('XF:Post');
        $postFinder
            ->where('Thread.discussion_state', 'visible')
            ->where('message_state', 'visible')
            ->where('reaction_score', '>=', $options->cb_potw_reaction_limit ?? 1)
            ->where('post_date', '>=', $start)
            ->where('post_date', '<=', $end);

        $nodeIds = $options->cb_potw_applicable_forum ?? [];
        if (!empty($nodeIds) && !in_array(0, $nodeIds)) {
            $postFinder->where('Thread.node_id', $nodeIds);
        }

        return $postFinder->total() > 0;
    }

    protected static function alertWatchers(string $timeLapse, string $template, \XF\Phrase $title): bool
    {
        $watchRepo = \XF::app()->repository('CoderBeams\POTW:Watch');
        $alertRepo = \XF::app()->repository('XF:UserAlert');

        $watches = $watchRepo->getWatchedUsers($timeLapse);
        if (!$watches->count()) {
            return false;
        }

        $extra = [
            'title' => $title->render(),
            'link' => \XF::app()->router('public')->buildLink('potw'),
        ];

        foreach ($watches as $watch) {
            if (!$watch->User) {
                continue;
            }

            $alertRepo->alert(
                $watch->User, // User being alerted
                $watch->user_id,
                '',
                'user', // Content type for Post of the Week watch alert
                $watch->user_id,
                $template,
                $extra
            );
        }

        return true;
    }
}
